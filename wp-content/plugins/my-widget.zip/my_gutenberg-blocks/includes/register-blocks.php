<?php
/*
function my_gutenberg_register_blocks(){
    $asset_file = include (plugin_dir_path(__FILE__) ."../build/index.asset.php");

    wp-register-script(
        "my-gutengerg-blocks",
        plugins_url("build/index.js", __DIR__.'/../'),
        $asset_file['dependencies'],
        $asset_file['version']
    );
    
}*/