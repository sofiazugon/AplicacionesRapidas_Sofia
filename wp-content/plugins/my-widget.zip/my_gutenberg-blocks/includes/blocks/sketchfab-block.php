<?php register_block_type('my-blocks/sketchfab',[
      'editor_script'=> 'my-blocks-editor',
      'editor_style'=> 'my-blocks-editor-style',
      'style'=> 'my-blocks-style',
  ]);